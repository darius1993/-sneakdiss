exports.validateUsername = function(username, errors){
    if (!username) {
        errors.push("Missing username");
    } else if (username.length < 3) {
        errors.push("Username must be at least 3 characters");
    } else if (username.indexOf("@")!= -1) {
        errors.push("Username may not contain an '@' sign");
    }
}

exports.validateSession = function(usersessionid, errors){
	if (!usersessionid) {
        errors.push("missing usersessionid");
	}
}

