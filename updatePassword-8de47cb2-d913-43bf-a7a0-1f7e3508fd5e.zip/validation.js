exports.validateUsername = function(username, errors){
    if (!username) {
        errors.push("Missing username");
    } else if (username.length < 3) {
        errors.push("Username must be at least 3 characters");
    } else if (username.indexOf("@")!= -1) {
        errors.push("Username may not contain an '@' sign");
    }
}

exports.validatePasswordHash = function(passwordHash, errors){
	if (!passwordHash) {
        errors.push("Missing password");
	}
}

exports.validateEmail = function(email, errors){
	if (!email) {
        errors.push("Missing email");
	} 
}

exports.validateRegistrationCode = function(registrationcode, errors){
	if (!registrationcode) {
        errors.push("Missing registrationcode");
	} 
}

exports.validatePassword = function(password, errors){
	if (!password) {
        errors.push("missing password");
	} 
}
exports.validatepasswordresetid = function(passwordresetid, errors){
	if (!passwordresetid) {
        errors.push("invalid passwordrequestid");
	} 
}
exports.userId = function(userId, errors){
	if (!userId) {
        errors.push("missing userid");
	} 
}